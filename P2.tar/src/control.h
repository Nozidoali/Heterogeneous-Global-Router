#include <string>
#include <sstream>
#include <cassert>
#include <vector>
#include <iostream>
#include <cstdlib>
#include <exception>
#include <fstream>
#include <queue>
#include <list>
#include <algorithm>
#include <map>

using namespace std;