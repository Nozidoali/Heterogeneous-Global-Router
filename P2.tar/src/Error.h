#ifndef ERROR_H
#define ERROR_H

#include "control.h"

class Exception 
{

};

#endif