#ifndef GLOBAL_H
#define GLOBAL_H

/**
 * Global Definitions
 */
static const int SUCCESS = 1;
static const int FAILED = 0;

#endif