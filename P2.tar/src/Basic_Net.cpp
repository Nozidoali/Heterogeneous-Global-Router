#include "Basic_Net.h"


/**
 * Update
 * 
 * update the utility of the net
 */
void Net :: Update( Segment * segment ) {
    
}