#ifndef POINT_H
#define POINT_H

#include "../router.h"

#endif