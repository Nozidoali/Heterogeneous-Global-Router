#include <string>
#include <sstream>
#include <cassert>
#include <vector>
#include <iostream>
#include <cstdlib>
#include <exception>
#include <fstream>
#include <queue>
#include <list>
#include <algorithm>
#include <map>
#include <set>

using namespace std;